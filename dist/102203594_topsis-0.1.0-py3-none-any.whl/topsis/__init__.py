# topsis/__init__.py
from .topsis import topsis
